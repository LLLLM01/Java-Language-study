﻿@[TOC](目录)
## 11.1 Linux Server服务器说明

> **详见：[Ubuntu Server 20.04LTS下载及安装教程](https://blog.csdn.net/qq_46207024/article/details/116562487)**

## 11.2 后话

## 11.3 SSH远程登录

> **详见：[PUTTY-0.75下载安装及SSH远程连接方法](https://blog.csdn.net/qq_46207024/article/details/116567533)**

## 11.4 WSL提及

> **详见：[适用于 Linux 的 Windows子系统(WSL)安装指南](https://blog.csdn.net/qq_46207024/article/details/116572048)**

