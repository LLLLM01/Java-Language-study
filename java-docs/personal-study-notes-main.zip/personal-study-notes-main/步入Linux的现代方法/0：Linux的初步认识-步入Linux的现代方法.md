﻿@[TOC](目录)

## 0.0 系统的认识

 - 什么是系统？
 - 鼠标能点、键盘能输入东西、阅读看电影，还可以拓展安装一些软件， 简单来说就是人机交互所依赖的东西，开机依赖系统

## 0.1 Linux操作系统认识，以及开源的提出：Linux的千奇百怪的版本

 - 目前世界上流行的电脑系统： 
 - Windows- Bill Gates (比尔·盖茨) 
 - GNU/Linux-Linus Benedict Torvalds(林納斯·托瓦茲)-开源 
 - Unix(Linux的爸爸)- 湯普遜和里奇合-给政府机关、公司等机构付费使用 
   Linux发行版本：Ubuntu Centos Red Hat Kali ……

## 0.2 开源的含义

 - 公开、分享、共同进步 
 - 开源不一定免费

## 0.3 Linux的用途，各类发行版本
Linux主要运用在服务器上
 - Linux严格来说是单指操作系统的内核，因操作系统中包含了许多用户图形接口和其他实用工具
 - 只要遵循GNU 通用公共许可证（GPL），任何个人和机构都可以自由地使用Linux的所有底层源代码，也可以自由地修改和再发布


Linux衍生：

 - Debian—Ubuntu,Deepin,Raspberry Pi OS,Knopix
 - Fedora—RedHat,Centos,Moblin 
 - OpenSUSE—GeckoLinux,openSUSE EcoLab Spin


